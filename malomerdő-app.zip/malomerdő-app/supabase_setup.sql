-- ============================================================
-- MALOMERDŐ PANZIÓ – Supabase adatbázis beállítás
-- Futasd le a Supabase Dashboard > SQL Editor-ban
-- ============================================================

-- 1. SZOBÁK tábla
CREATE TABLE IF NOT EXISTS rooms (
  id          INTEGER PRIMARY KEY,
  building    TEXT    NOT NULL CHECK (building IN ('kastely', 'paraszthaz')),
  name        TEXT    NOT NULL,
  guests      INTEGER NOT NULL DEFAULT 2,
  status      TEXT    NOT NULL DEFAULT 'clean'
              CHECK (status IN ('clean', 'checkin', 'checkout', 'occupied')),
  note        TEXT    DEFAULT '',
  cleaning    TEXT    NOT NULL DEFAULT 'normal' CHECK (cleaning IN ('normal', 'deep')),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- 2. ESEMÉNYEK tábla
CREATE TABLE IF NOT EXISTS events (
  id            SERIAL PRIMARY KEY,
  type          TEXT    NOT NULL,
  date          DATE    NOT NULL DEFAULT CURRENT_DATE,
  time          TEXT    NOT NULL DEFAULT '00:00',
  place         TEXT    NOT NULL DEFAULT 'Étterem',
  count         INTEGER NOT NULL DEFAULT 0,
  note          TEXT    DEFAULT '',
  catering      TEXT    DEFAULT 'Nincs catering',
  takeaway      BOOLEAN DEFAULT FALSE,
  takeaway_time TEXT    DEFAULT '',
  takeaway_who  TEXT    DEFAULT '',
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- 3. WELLNESS FOGLALÁSOK tábla
CREATE TABLE IF NOT EXISTS wellness (
  id         SERIAL PRIMARY KEY,
  type       TEXT NOT NULL CHECK (type IN ('jacuzzi', 'sauna')),
  time       TEXT NOT NULL,
  guest      TEXT NOT NULL,
  date       DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE (type, time, date)
);

-- 4. MŰSZAKÁTADÓ tábla (egyetlen sor, id=1)
CREATE TABLE IF NOT EXISTS shift (
  id         INTEGER PRIMARY KEY DEFAULT 1,
  message    TEXT DEFAULT '',
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

INSERT INTO shift (id, message) VALUES (1, '')
ON CONFLICT (id) DO NOTHING;

-- ============================================================
-- ROW LEVEL SECURITY (RLS) – Belső hálózathoz ajánlott
-- Ha publikusan éred el, kapcsold be az RLS-t és add meg
-- az anon key-nek az engedélyeket
-- ============================================================

-- Szobák: mindenki olvashatja és módosíthatja (belső app)
ALTER TABLE rooms    ENABLE ROW LEVEL SECURITY;
ALTER TABLE events   ENABLE ROW LEVEL SECURITY;
ALTER TABLE wellness ENABLE ROW LEVEL SECURITY;
ALTER TABLE shift    ENABLE ROW LEVEL SECURITY;

-- Olvasás és írás az anon (nem hitelesített) felhasználóknak
CREATE POLICY "anon_all_rooms"    ON rooms    FOR ALL TO anon USING (true) WITH CHECK (true);
CREATE POLICY "anon_all_events"   ON events   FOR ALL TO anon USING (true) WITH CHECK (true);
CREATE POLICY "anon_all_wellness" ON wellness FOR ALL TO anon USING (true) WITH CHECK (true);
CREATE POLICY "anon_all_shift"    ON shift    FOR ALL TO anon USING (true) WITH CHECK (true);

-- ============================================================
-- REALTIME – Kapcsold be a táblákon
-- ============================================================
-- Supabase Dashboard > Database > Replication > Source
-- Kapcsold be: rooms, events, wellness, shift

-- ============================================================
-- KÉSZ! Ezután másold be az index.html tetejére:
-- SUPABASE_URL = 'https://XXXXXX.supabase.co'
-- SUPABASE_KEY = 'eyXXXXXXXX...'  (anon public key)
-- ============================================================
